package com.example.web_demo.service;

import com.example.web_demo.model.Employee;
import com.example.web_demo.repository.EmployeeRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepo employeeRepo;

    // Create a new employee.
    public Employee createEmployee(Employee employee) {
        validate(employee);
        employee.setId(0);
        return employeeRepo.save(employee);
    }

    // Get All Employees
    public List<Employee> getAllEmployees() {
        return employeeRepo.findAll();
    }

    // Get Employee By Id
    public Employee getEmployeeById(Long id) {
        Optional<Employee> opt = employeeRepo.findById(id);
        if (opt.isPresent()) {
            return opt.get();
        }
        return null;
    }

    // Update Employee
    public Employee updateEmployee(Long id, Employee employeeDetails) {
        Employee employee = getEmployeeById(id);
        if (employee != null) {
            validate(employeeDetails);
            employee.setName(employeeDetails.getName());
            employee.setDepartment(employeeDetails.getDepartment());
            employee.setSalary(employeeDetails.getSalary());
            return employeeRepo.save(employee);
        }
        return null;
    }

    // Delete Employee. Returns true if an employee was found and deleted.
    public boolean deleteEmployee(Long id) {
        Employee employee = getEmployeeById(id);
        if (employee != null) {
            employeeRepo.delete(employee);
            return true;
        }
        return false;
    }

    private void validate(Employee employee) {
        if (employee.getName() == null || employee.getName().trim().length() < 3) {
            throw new IllegalArgumentException("Name must contain at least 3 characters");
        }
        if (employee.getDepartment() == null || employee.getDepartment().trim().isEmpty()) {
            throw new IllegalArgumentException("Department is required");
        }
        if (employee.getSalary() == null || !Double.isFinite(employee.getSalary()) || employee.getSalary() < 0) {
            throw new IllegalArgumentException("Salary must be a non-negative number");
        }
        employee.setName(employee.getName().trim());
        employee.setDepartment(employee.getDepartment().trim());
    }
}
