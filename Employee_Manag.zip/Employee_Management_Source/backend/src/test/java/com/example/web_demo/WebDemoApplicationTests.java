package com.example.web_demo;

import com.example.web_demo.repository.EmployeeRepo;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;

import static org.hamcrest.Matchers.hasSize;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
class WebDemoApplicationTests {
    @Autowired MockMvc mvc;
    @Autowired EmployeeRepo repository;
    @Autowired ObjectMapper mapper;

    @BeforeEach void clearData() { repository.deleteAll(); }

    @Test void crudRoundTrip() throws Exception {
        String response = mvc.perform(post("/create").contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"Asha Rao\",\"department\":\"Finance\",\"salary\":42000}"))
                .andExpect(status().isCreated()).andReturn().getResponse().getContentAsString();
        long id = mapper.readTree(response).get("id").asLong();
        mvc.perform(get("/list")).andExpect(status().isOk()).andExpect(jsonPath("$", hasSize(1)));
        mvc.perform(get("/list/" + id)).andExpect(status().isOk()).andExpect(jsonPath("$.name").value("Asha Rao"));
        mvc.perform(put("/update/" + id).contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"Asha Rao\",\"department\":\"Operations\",\"salary\":45000}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.salary").value(45000));
        mvc.perform(delete("/rm/" + id)).andExpect(status().isNoContent());
        mvc.perform(get("/list")).andExpect(jsonPath("$", hasSize(0)));
        mvc.perform(get("/list/" + id)).andExpect(status().isNotFound());
    }

    @Test void rejectsBlankName() throws Exception {
        invalid("{\"name\":\"   \",\"department\":\"IT\",\"salary\":100}");
    }
    @Test void rejectsBlankDepartment() throws Exception {
        invalid("{\"name\":\"Asha Rao\",\"department\":\"   \",\"salary\":100}");
    }
    @Test void rejectsNegativeSalary() throws Exception {
        invalid("{\"name\":\"Asha Rao\",\"department\":\"IT\",\"salary\":-1}");
    }
    @Test void rejectsMissingSalary() throws Exception {
        invalid("{\"name\":\"Asha Rao\",\"department\":\"IT\"}");
    }
    @Test void rejectsNonNumericSalary() throws Exception {
        invalid("{\"name\":\"Asha Rao\",\"department\":\"IT\",\"salary\":\"abc\"}");
    }
    @Test void unknownIdReturns404() throws Exception {
        mvc.perform(get("/list/999999")).andExpect(status().isNotFound());
        mvc.perform(put("/update/999999").contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"Asha Rao\",\"department\":\"IT\",\"salary\":100}"))
                .andExpect(status().isNotFound());
        mvc.perform(delete("/rm/999999")).andExpect(status().isNotFound());
    }
    @Test void corsPreflightAllowsAngularOrigin() throws Exception {
        mvc.perform(options("/create").header("Origin", "http://localhost:4200")
                .header("Access-Control-Request-Method", "POST"))
                .andExpect(status().isOk())
                .andExpect(header().string("Access-Control-Allow-Origin", "http://localhost:4200"));
    }
    @Test void updateRejectsInvalidValues() throws Exception {
        String response = mvc.perform(post("/create").contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"Asha Rao\",\"department\":\"IT\",\"salary\":100}"))
                .andReturn().getResponse().getContentAsString();
        long id = mapper.readTree(response).get("id").asLong();
        mvc.perform(put("/update/" + id).contentType(MediaType.APPLICATION_JSON)
                .content("{\"name\":\"Asha Rao\",\"department\":\"IT\",\"salary\":-10}"))
                .andExpect(status().isBadRequest());
        mvc.perform(get("/list/" + id)).andExpect(jsonPath("$.salary").value(100));
    }
    private void invalid(String body) throws Exception {
        mvc.perform(post("/create").contentType(MediaType.APPLICATION_JSON).content(body))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.message").exists());
        mvc.perform(get("/list")).andExpect(jsonPath("$", hasSize(0)));
    }
}
