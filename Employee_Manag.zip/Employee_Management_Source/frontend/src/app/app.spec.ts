import { TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { App } from './app';

describe('App shell', () => {
  it('contains the employee screen', async () => {
    await TestBed.configureTestingModule({ declarations: [App], schemas: [NO_ERRORS_SCHEMA] }).compileComponents();
    const fixture = TestBed.createComponent(App);
    fixture.detectChanges();
    expect(fixture.nativeElement.querySelector('app-employee')).toBeTruthy();
  });
});
