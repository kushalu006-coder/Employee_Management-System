import { ComponentFixture, TestBed } from '@angular/core/testing';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { of } from 'rxjs';
import { vi } from 'vitest';
import { EmployeeComponent } from './employee';
import { EmployeeService } from '../employee-service';

describe('Employee form', () => {
  let component: EmployeeComponent;
  let fixture: ComponentFixture<EmployeeComponent>;
  const service = {
    getAllEmployees: vi.fn(() => of([])),
    createEmployee: vi.fn(() => of({ id: 1, name: 'Asha Rao', department: 'IT', salary: 100 })),
    updateEmployee: vi.fn(() => of({ id: 1, name: 'Asha Rao', department: 'IT', salary: 100 })),
    deleteEmployee: vi.fn(() => of(undefined))
  };
  beforeEach(async () => {
    vi.clearAllMocks();
    await TestBed.configureTestingModule({
      declarations: [EmployeeComponent],
      imports: [CommonModule, ReactiveFormsModule],
      providers: [{ provide: EmployeeService, useValue: service }]
    }).compileComponents();
    fixture = TestBed.createComponent(EmployeeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });
  it('blocks empty input without calling the API', () => {
    component.saveEmployee();
    expect(component.employeeForm.invalid).toBe(true);
    expect(component.name?.touched).toBe(true);
    expect(service.createEmployee).not.toHaveBeenCalled();
  });
  it('blocks a negative salary', () => {
    component.employeeForm.setValue({ name: 'Asha Rao', department: 'IT', salary: -1 });
    component.saveEmployee();
    expect(service.createEmployee).not.toHaveBeenCalled();
  });
  it('trims and saves valid employee details', () => {
    component.employeeForm.setValue({ name: ' Asha Rao ', department: ' IT ', salary: 100 });
    component.saveEmployee();
    expect(service.createEmployee).toHaveBeenCalledWith({ name: 'Asha Rao', department: 'IT', salary: 100 });
    expect(component.message).toBe('Employee created successfully.');
  });
  it('populates and updates an existing employee', () => {
    component.editEmployee({ id: 1, name: 'Asha Rao', department: 'IT', salary: 100 });
    component.employeeForm.patchValue({ salary: 200 });
    component.saveEmployee();
    expect(service.updateEmployee).toHaveBeenCalledWith(1, { name: 'Asha Rao', department: 'IT', salary: 200 });
  });
  it('only deletes after confirmation is submitted', () => {
    component.pendingDelete = { id: 1, name: 'Asha Rao', department: 'IT', salary: 100 };
    expect(service.deleteEmployee).not.toHaveBeenCalled();
    component.confirmDelete();
    expect(service.deleteEmployee).toHaveBeenCalledWith(1);
  });
});
