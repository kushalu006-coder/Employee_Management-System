import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { HttpErrorResponse } from '@angular/common/http';
import { EmployeeService } from '../employee-service';
import { Employee } from '../employee';

@Component({
  selector: 'app-employee',
  standalone: false,
  templateUrl: './employee.html',
  styleUrl: './employee.css'
})
export class EmployeeComponent implements OnInit {
  employeeForm!: FormGroup;
  employees: Employee[] = [];
  editMode = false;
  selectedEmployeeId?: number;
  pendingDelete?: Employee;
  message = '';
  errorMessage = '';
  saving = false;
  deleting = false;

  constructor(private fb: FormBuilder, private employeeService: EmployeeService) {}

  ngOnInit(): void {
    this.employeeForm = this.fb.group({
      name: ['', [Validators.required, Validators.minLength(3), Validators.pattern(/\S/)]],
      department: ['', [Validators.required, Validators.pattern(/\S/)]],
      salary: [null, [Validators.required, Validators.min(0)]]
    });
    this.loadEmployees();
  }

  loadEmployees(): void {
    this.employeeService.getAllEmployees().subscribe({
      next: data => this.employees = data,
      error: error => this.showError(error)
    });
  }

  saveEmployee(): void {
    this.errorMessage = '';
    this.message = '';
    this.employeeForm.patchValue({
      name: String(this.employeeForm.value.name ?? '').trim(),
      department: String(this.employeeForm.value.department ?? '').trim()
    });
    if (this.employeeForm.invalid || this.saving) {
      this.employeeForm.markAllAsTouched();
      return;
    }
    const employee: Employee = {
      name: this.employeeForm.value.name,
      department: this.employeeForm.value.department,
      salary: Number(this.employeeForm.value.salary)
    };
    const updating = this.editMode && this.selectedEmployeeId !== undefined;
    const request = updating
      ? this.employeeService.updateEmployee(this.selectedEmployeeId!, employee)
      : this.employeeService.createEmployee(employee);
    this.saving = true;
    request.subscribe({
      next: () => {
        this.saving = false;
        this.message = updating ? 'Employee updated successfully.' : 'Employee created successfully.';
        this.resetForm();
        this.loadEmployees();
      },
      error: error => { this.saving = false; this.showError(error); }
    });
  }

  editEmployee(employee: Employee): void {
    this.editMode = true;
    this.selectedEmployeeId = employee.id;
    this.employeeForm.patchValue(employee);
    this.message = '';
    this.errorMessage = '';
  }

  confirmDelete(): void {
    const id = this.pendingDelete?.id;
    if (id === undefined || this.deleting) return;
    this.deleting = true;
    this.employeeService.deleteEmployee(id).subscribe({
      next: () => {
        this.deleting = false;
        this.pendingDelete = undefined;
        if (this.selectedEmployeeId === id) this.resetForm();
        this.errorMessage = '';
        this.message = 'Employee deleted successfully.';
        this.loadEmployees();
      },
      error: error => { this.deleting = false; this.showError(error); }
    });
  }

  resetForm(): void {
    this.employeeForm.reset();
    this.editMode = false;
    this.selectedEmployeeId = undefined;
  }

  private showError(error: HttpErrorResponse): void {
    this.message = '';
    this.errorMessage = error.status === 0
      ? 'Cannot connect to the server. Check that the backend is running on port 8080.'
      : error.error?.message || `Request failed (${error.status}). Please try again.`;
  }

  get name() { return this.employeeForm.get('name'); }
  get department() { return this.employeeForm.get('department'); }
  get salary() { return this.employeeForm.get('salary'); }
}
