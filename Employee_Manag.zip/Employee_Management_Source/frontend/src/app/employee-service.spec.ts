import { TestBed } from '@angular/core/testing';
import { provideHttpClient } from '@angular/common/http';
import { HttpTestingController, provideHttpClientTesting } from '@angular/common/http/testing';
import { EmployeeService } from './employee-service';

describe('EmployeeService HTTP requests', () => {
  let service: EmployeeService;
  let http: HttpTestingController;
  const employee = { name: 'Asha Rao', department: 'Finance', salary: 42000 };
  beforeEach(() => {
    TestBed.configureTestingModule({ providers: [provideHttpClient(), provideHttpClientTesting()] });
    service = TestBed.inject(EmployeeService);
    http = TestBed.inject(HttpTestingController);
  });
  afterEach(() => http.verify());
  it('loads the employee list', () => {
    service.getAllEmployees().subscribe(data => expect(data.length).toBe(1));
    const request = http.expectOne('http://localhost:8080/list');
    expect(request.request.method).toBe('GET');
    request.flush([{ ...employee, id: 1 }]);
  });
  it('sends employee values to create', () => {
    service.createEmployee(employee).subscribe();
    const request = http.expectOne('http://localhost:8080/create');
    expect(request.request.method).toBe('POST');
    expect(request.request.body).toEqual(employee);
    request.flush({ ...employee, id: 1 });
  });
  it('reads an employee by ID', () => {
    service.getEmployeeById(1).subscribe();
    const request = http.expectOne('http://localhost:8080/list/1');
    expect(request.request.method).toBe('GET');
    request.flush({ ...employee, id: 1 });
  });
  it('updates the selected employee', () => {
    service.updateEmployee(1, employee).subscribe();
    const request = http.expectOne('http://localhost:8080/update/1');
    expect(request.request.method).toBe('PUT');
    expect(request.request.body).toEqual(employee);
    request.flush({ ...employee, id: 1 });
  });
  it('deletes the selected employee', () => {
    service.deleteEmployee(1).subscribe();
    const request = http.expectOne('http://localhost:8080/rm/1');
    expect(request.request.method).toBe('DELETE');
    request.flush(null, { status: 204, statusText: 'No Content' });
  });
});
