# Employee Management frontend

See the project README at `../README.md` for prerequisites, backend setup, frontend commands, API configuration, tests and limitations.
