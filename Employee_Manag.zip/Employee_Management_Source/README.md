# Employee Management

A small Angular and Spring Boot application for creating, viewing, editing and deleting employee records. Each record has an ID, name, department and salary. The database table is named `tablename.

## Requirements

- JDK 17 or newer. The source targets Java 17 and also builds with JDK 21.
- Node.js 22.12 or newer in the Node 22 line, or Node.js 24. A Node 24 runtime was used for verification.
- npm and an internet connection for the first dependency download.
- MySQL for the default database configuration. The separate H2 demo profile does not require MySQL.
- Ports 4200 and 8080 available.

## Quick start with the local H2 database

Open a terminal in `backend`.

Windows PowerShell:

```powershell
.\mvnw.cmd spring-boot:run "-Dspring-boot.run.profiles=demo"
```

macOS or Linux:

```sh
chmod +x mvnw
./mvnw spring-boot:run -Dspring-boot.run.profiles=demo
```

Open a second terminal in `frontend`:

```sh
npm ci
npm start
```

Visit http://localhost:4200. Start with the empty list and add a record. H2 saves records in `backend/data/employees.mv.db`; this file is generated locally and is excluded from the source ZIP. Restarting the demo backend keeps the records. Automated backend tests use a different, in-memory database.

## Run with MySQL

1. Start your local MySQL service.
2. In the MySQL client, create the database: `CREATE DATABASE IF NOT EXISTS admindb;`.
3. Set `DB_USERNAME` and `DB_PASSWORD` in your IDE run configuration or local terminal. Use your own account with permissions on `admindb`. Do not save the password in the project. `DB_URL` defaults to `jdbc:mysql://localhost:3306/admindb` and can be overridden.
4. In `backend`, run `mvnw.cmd spring-boot:run` on Windows or `./mvnw spring-boot:run` on macOS/Linux, without the demo profile.
5. Start the frontend as above. Hibernate creates or updates the table using `ddl-auto=update`.

`database/schema-mysql.sql` documents the table definition. The MySQL configuration is retained from the lab project, with credentials moved to environment variables. The supplied verification evidence uses H2; a live MySQL run has not been verified here.

## Configuration

- Frontend: http://localhost:4200
- Backend: http://localhost:8080
- API base URL: `frontend/src/app/employee-service.ts`
- Allowed browser origin: `backend/src/main/java/com/example/web_demo/config/WebConfig.java`
- MySQL connection: `backend/src/main/resources/application.properties`
- H2 demo connection: `backend/src/main/resources/application-demo.properties`

If you change the frontend port or hostname, update the allowed CORS origin. If you change the backend port, update the API base URL. The URLs use `localhost`; use that hostname when opening the frontend.

## API

| Operation | Method and path | Success | Missing ID |
| --- | --- | --- | --- |
| Create | POST /create | 201 with saved employee | Not applicable |
| List | GET /list | 200 with JSON array | Not applicable |
| Read one | GET /list/{id} | 200 with employee | 404 |
| Update | PUT /update/{id} | 200 with updated employee | 404 |
| Delete | DELETE /rm/{id} | 204 with no body | 404 |

Create/update body:

```json
{"name":"Asha Rao","department":"Finance","salary":42000}
```

The server generates the ID on create. Invalid names, blank departments, missing or negative salaries, and malformed numeric input return HTTP 400 with a JSON `message`. The browser also validates the form. The salary has no defined currency or pay period in this lab application.

Import `api/Employee_Management.postman_collection.json` into Postman if desired. Postman is optional; the Angular frontend and backend integration tests also exercise these endpoints. Test with fictional records only.

## Tests and build

Backend:

```sh
./mvnw test
./mvnw package
```

On Windows use `mvnw.cmd` in place of `./mvnw`. The tests automatically select the `test` profile and never connect to MySQL.

Frontend:

```sh
npm test -- --watch=false
npm run build
```

The Angular build is written to `frontend/dist/angular-app/`. The executable Spring Boot JAR is written to `backend/target/`. Generated output is intentionally absent from the source ZIP.

## Inspect the demo database

With the demo backend running, open http://localhost:8080/h2-console. Choose the H2 embedded driver, JDBC URL `jdbc:h2:file:./data/employees`, user `sa`, and leave the password empty. This empty-password account belongs only to the local demo profile; it is not a MySQL credential. Run:

```sql
SELECT id, name, department, salary FROM tablename ORDER BY id;
```


## Scope and limitations

There is one entity, Employee. Department is a text field, not a separate table. There are no foreign keys or entity relationships. Authentication, roles, pagination, search, salary calculations, an audit trail and duplicate detection are outside the current scope. Salary uses `Double`; a real payroll system should use a fixed-precision decimal type with a stated currency and pay period. The current validation does not impose maximum text lengths matching the database columns. This is a local lab application, with no production deployment claim.
