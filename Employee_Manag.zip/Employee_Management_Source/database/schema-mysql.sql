-- Schema reference for the lab project. Hibernate can create this table.
CREATE DATABASE IF NOT EXISTS admindb;
USE admindb;
CREATE TABLE IF NOT EXISTS tablename (
    id BIGINT NOT NULL AUTO_INCREMENT,
    name VARCHAR(255),
    department VARCHAR(255),
    salary DOUBLE,
    PRIMARY KEY (id)
);
-- The application validates values before saving. There are no foreign keys.
